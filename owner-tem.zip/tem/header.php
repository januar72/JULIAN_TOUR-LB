<!DOCTYPE html>
<html lang="en">

<head>
    <title>JK TOUR KOMODO</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="depan/aset/css/styles.css">

    <!-- awal fontawesome -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- akhir fontawesome -->

     <!-- icon boostrap -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <!-- akhir icon -->

    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta content="#000" name="msapplication-TileColor">
    <meta content="#000" name="theme-color">
</head>

<body>
    <div class="container">
        <div class="header">
            <div class="wrap">
                <div class="wrap_float">
                    <div class="header__top">
                        <?php include 'koneksi.php';
                        $tam=mysqli_query($konek, "SELECT * FROM tb_soc");
                        while ($data=mysqli_fetch_array($tam, MYSQLI_ASSOC)) {?>
                        <div class="tel">
                            <a href="tel:<?php echo $data['hp']; ?>"><?php echo $data['hp']; ?> </a>
                        </div>
                        <div class="email">
                            <a href="mailto:<?php echo $data['email']; ?>"><?php echo $data['email']; ?></a>
                        </div>
                         <?php } ?>
                        <div class="socials">
                            <?php include 'koneksi.php';
                            $data_a=mysqli_query($konek, "SELECT * FROM tb_soc");
                            while ($data_b=mysqli_fetch_array($data_a, MYSQLI_ASSOC)) { ?>
                            <a href="<?php echo $data_g['ig']; ?>" style="font-weight: bold; color: red; margin: 10px;"><i class="bi bi-instagram"></i></a>

                            <a href="<?php echo $data_g['tiktok']; ?>" style="font-weight: bold; color: white; margin: 10px;"><i class="bi bi-tiktok"></i></a>

                            <a href="<?php echo $data_g['fb']; ?>" style="font-weight: bold; color: blue; margin: 10px;"><i class="bi bi-facebook"></i></a>

                            <?php } ?>
                        </div>
                    </div>
                    <div class="header__bottom">
                        <a href="index.php" class="logo">JK LAND TRIP</a>
                        <div class="menu" id="js-menu">
                            <div class="close"></div>
                            <div class="scroll">
                                <a class="current">Home</a>
                                <div class="scroll_wrap">
                                    <ul>
                                        <li><a href="index.php" class="active">Home</a></li>
                                        <li class="dropdown_li">
                                            <a href="#">
                                                <span>Halaman</span>
                                            </a>
                                            <div class="dropdown-menu">
                                                <ul>
                                                    <li><a href="about.php">About</a></li>
                                                    <li><a href="login.php"> Login</a></li>
                                                </ul>
                                            </div>
                                        </li>
                                        <li><a href="destinations.php">Paket Wisata</a></li>
                                        
                                        <li><a href="contacts.php">Contact</a></li>
                                    </ul>
                                </div>
                                <div class="bottom">
                                    <?php include 'koneksi.php';
                                    $data=mysqli_query($konek, "SELECT * FROM tb_soc");
                                    while ($dat=mysqli_fetch_array($data, MYSQLI_ASSOC)) {?>
                                    <div class="tel">
                                        <a href="tel:<?php echo $dat['hp']; ?>"><?php echo $dat['hp']; ?></a>
                                    </div>
                                    <div class="email">
                                        <a href="mailto:<?php echo $dat['email']; ?>"><?php echo $dat['email']; ?></a>
                                    </div>
                                    <div class="socials">
                                        <div class="links">
                                            <a href="<?php echo $data_g['ig']; ?>" style="font-weight: bold; color: red; margin: 10px;"><i class="bi bi-instagram"></i></a>

                                            <a href="<?php echo $data_g['tiktok']; ?>" style="font-weight: bold; color: white; margin: 10px;"><i class="bi bi-tiktok"></i></a>

                                            <a href="<?php echo $data_g['fb']; ?>" style="font-weight: bold; color: blue; margin: 10px;"><i class="bi bi-facebook"></i></a>
                                        </div>
                                    </div>
                                    <?php } ?>
                                </div>
                            </div>
                        </div>
                        <div class=""></div>
                        <div class="mobile_btn" id="mobile_btn">
                            <span></span>
                            <span></span>
                            <span></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>