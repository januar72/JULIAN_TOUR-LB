
        <div class="footer">
            <div class="footer_top">
                <div class="wrap">
                    <div class="wrap_float">
                        <div class="footer_head_mobile">
                            <div class="logo">JK LAND TRIP</div>
                            <div class="text">
                                Rental Mobil Terbaik dan termurah hanya di Jk Land Trip dan pilih kategori Wisata yang akan anda kunjungi.
                            </div>
                        </div>
                        <div class="footer_top_menu">
                            <ul>
                                <li><a href="index.php" class="active">Home</a></li>
                                <li><a href="about.php">About</a></li>
                                <li><a href="destinations.php">Wisata</a></li>
                                <li><a href="contacts.php">Kontak</a></li>
                                <li><a href="index.php">Rental Mobil</a></li>
                            </ul>
                        </div>
                        <div class="socials">
                            <?php include 'koneksi.php';
                            $tam=mysqli_query($konek, "SELECT * FROM tb_soc");
                            while ($data=mysqli_fetch_array($tam, MYSQLI_ASSOC)) {?>
                            
                            <a href="<?php echo $data['fb']; ?>" style="font-weight: bold; color: blue; width: 80px; height: 100px; margin: 10px;"><i class="bi bi-facebook"></i></a>

                            <a href="<?php echo $data['tiktok']; ?>" style="font-weight: bold; color: ; width: 80px; height: 100px; margin: 10px;"><i class="bi bi-tiktok"></i></a>

                            <a href="<?php echo $data['ig']; ?>" style="font-weight: bold; color: red; width: 80px; height: 100px; margin: 10px;"><i class="bi bi-instagram"></i></a>

                            <?php } ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="footer_center">
                <div class="wrap">
                    <div class="wrap_float">
                        <div class="footer_center_left">
                            <a href="index.php" class="logo">JK LAND TRIP</a>
                            <div class="text">
                                Rental Mobil Terbaik dan termurah hanya di Jk Land Trip dan pilih kategori Wisata yang akan anda kunjungi.
                            </div>
                        </div>
                        <div class="footer_center_menu">
                            <ul>
                                <li><a href="#">Rental Mobil</a></li>
                                <li><a href="#">Liburan</a></li>
                                <li><a href="#">Wisata</a></li>
                                <li><a href="#">Kunjungan</a></li>
                            </ul>
                        </div>
                        <div class="footer_center_right">
                            <div class="_title">CONTACTS</div>
                            <div class="text">
                                <p>Alamat: <b>Wae Kelambu, Kec. Komodo, Kabupaten Manggarai Barat, Nusa Tenggara Timur.</b> </p>
                                <?php include 'koneksi.php';
                                $ta=mysqli_query($konek, "SELECT * FROM tb_soc");
                                while ($da=mysqli_fetch_array($ta, MYSQLI_ASSOC)) {?>
                                <p>Wa: <a href="#"><?php echo $da['hp']; ?></a></p>
                                <p><a href="#"><?php echo $da['email']; ?></a></p>
                                <?php } ?>
                            </div>
                        </div>
                        <div class="mobile_socials">
                            <?php include 'koneksi.php';
                            $tam_a=mysqli_query($konek, "SELECT * FROM tb_soc");
                            while ($data_g=mysqli_fetch_array($tam_a, MYSQLI_ASSOC)) {?>
                            <a href="<?php echo $data_g['ig']; ?>" style="font-weight: bold; color: red; margin: 10px;"><i class="bi bi-instagram"></i></a>

                            <a href="<?php echo $data_g['tiktok']; ?>" style="font-weight: bold; color: white; margin: 10px;"><i class="bi bi-tiktok"></i></a>

                            <a href="<?php echo $data_g['fb']; ?>" style="font-weight: bold; color: blue; margin: 10px;"><i class="bi bi-facebook"></i></a>
                            <?php } ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="footer_bottom">
                Copyright <?php echo date('Y'); ?> <a href="#">januar</a> | semua bisa#
            </div>
        </div>
    </div>

    <div class="search_form" id="search_form">
        <div class="wrap">
            <div class="wrap_float">
                <input type="text" class="input" placeholder="Search...">
                <button type="submit" class="submit"></button>
                <div class="close"></div>
            </div>
        </div>
    </div>
    <div class="overlay" id="overlay"></div>

    <div style="display: none;">
        <div class="modal modal_book_now" id="book-now">
            <div class="modal_wrap">
                <form method="post" action="proses_pesan.php">
                    <div class="modal-body">
                    <!-- <div class="tags">
                        <div class="tag discount">20% off</div>
                        <div class="tag new">New</div>
                    </div> -->
                    <div class="modal-title">
                        JK LAND TRIP
                    </div>
                    <div class="fields">
                        <div class="field half">
                            <label class="label" for="name-2">Nama Lengkap*</label>
                            <div class="input_wrap">
                                <input type="text" name="nama" required class="input" id="name-2">
                            </div>
                        </div>

                        <div class="field half">
                            <label class="label" for="email-2">Alamat Email*</label>
                            <div class="input_wrap">
                                <input type="email" name="email" required class="input" id="email-2">
                            </div>
                        </div>

                        <div class="field half">
                            <label class="label" for="date-2a">Tanggal Pesan*</label>
                            <div class="input_wrap calendar-field">
                                <input type="text" name="tgl" required class="input js_calendar" id="date-2a">
                            </div>
                        </div>
                        <div class="field half">
                            <p class="label">Jumlah Orang*</p>
                            <div class="input_wrap">
                                <input type="text" name="jumlah" required class="input" id="date-2">
                            </div>
                        </div>
                        <div class="field">
                            <label class="label" for="enquiry-2">No Wa*</label>
                            <input type="number" name="no_wa" class="input" required id="date-3">
                        </div>

                        <div class="field">
                            <label class="label" for="enquiry-2">Tulis Pesan*</label>
                            <div class="textarea_wrap">
                                <textarea class="textarea" required name="pesan" id="enquiry-2"></textarea>
                            </div>
                        </div>
                    </div>
                    <button class="btn submit" id="tombol" type="submit" name="simpan">Sumbit</button>
                </div>
                </form>
            </div>
            <div class="modal_close"></div>
        </div>
    </div>

    <script defer src="https://maps.googleapis.com/maps/api/js?key=YOUR_API_HERE&callback=initMap"></script>
    <script defer src="depan/aset/js/jquery.min.js"></script>
    <script defer src="depan/aset/js/jquery-ui.min.js"></script>
    <script defer src="depan/aset/js/slick.min.js"></script>
    <script defer src="depan/aset/js/jquery.arcticmodal.min.js"></script>
    <script defer src="depan/aset/js/lightgallery.js"></script>
    <script defer src="depan/aset/js/spincrement.min.js"></script>
    <script defer src="depan/aset/js/scripts.min.js"></script>


<script src="dist/js/sweetalert2.all.min.js"></script>
<script type="text/javascript">
  const tombol =document.querySelector('#tombol');
  tombol.addEventListener('click', function(){
    Swal.fire({
  title: 'Are you sure?',
  text: "data anda siap terkirim..!",
  icon: 'success',
  showCancelButton: true,
  confirmButtonColor: '#3085d6',
  cancelButtonColor: '#d33',
  confirmButtonText: 'Yes, siap terkirim..!'
}).then((result) => {
  if (result.isConfirmed) {
    Swal.fire(
      'ok..!',
      'data terkirim..',
      'success'
    )
  }
})
  });
</script>

      <!-- footer watshap -->
<script type="text/javascript">
    (function () {
        var options = {
            whatsapp: "+62 085337015900", // WhatsApp number
            call_to_action: "call me by watshap..!", // Call to action
            button_color: "#FF6550", // Color of button
            position: "left", // Position may be 'right' or 'left'
            pre_filled_message: "call me by watshap..!", // WhatsApp pre-filled message
        };
        var proto = 'https:', host = "getbutton.io", url = proto + '//static.' + host;
        var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true; s.src = url + '/widget-send-button/js/init.js';
        s.onload = function () { WhWidgetSendButton.init(host, proto, options); };
        var x = document.getElementsByTagName('script')[0]; x.parentNode.insertBefore(s, x);
    })();
</script>
<!-- /GetButton.io widget -->
</body>

</html>