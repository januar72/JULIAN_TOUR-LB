<section class="content-header">
        <h1>
          <small>LAPORAN PRODUKSI</small>
        </h1>
        <ol class="breadcrumb">
          <li><a href="#"><i class="fa fa-dashboard"></i> Dashboard</a></li>
          <li><a href="#">Owner</a></li>
          <li class="active">Laporan Produksi</li>
        </ol>
      </section>
      <section class="content">
        <div class="row">
         
          <div class="col-lg-12">
            <div class="box box-default">
              <div class="box-header with-border" style="overflow: auto;">
                <h3 class="box-title">Laporan Produksi</h3>
              </div>
              <div class="box-body" style="overflow: auto;">
                <div class="row">
                  <div class="col-lg-6">
                    <b>Pilih Periode Cetak Laporan:</b>
                    <hr>
                     <form role="form" method="post" target="_blank" action="./lap_produksi.php">
                      <div class="row">
                        <div class="col-lg-4">
                          <div class="form-group">
                            <label for="exampleInputEmail1">Bulan</label>
                            <select name="bulan" class="form-control" required="required">
                                  <option value="01">Januari</option>
                                  <option value="02">Februari</option>
                                  <option value="03">Maret</option>
                                  <option value="04">April</option>
                                  <option value="05">Mei</option>
                                  <option value="06">Juni</option>
                                  <option value="07">Juli</option>
                                  <option value="08">Agustus</option>
                                  <option value="09">September</option>
                                  <option value="10">Oktober</option>
                                  <option value="11">November</option>
                                  <option value="12">Desember</option>
                            </select>
                          </div>
                        </div>
                        <div class="col-lg-4">
                          <div class="form-group">
                            <label for="exampleInputEmail1">Tahun</label>
                            <select name="tahun" class="form-control" required="required">
                                  <?php
                                    $mulai= date('Y') - 50;
                                    for($i = $mulai; $i<$mulai + 100;$i++){
                                      $sel = $i == date('Y') ? ' selected="selected"' : '';
                                      echo '<option value="'.$i.'"'.$sel.'>'.$i.'</option>';
                                    }
                                    ?>
                                  </select>
                          </div>
                        </div>
                       
                        <div class="col-lg-4">
                          <button type="submit" class="btn btn-default" style="margin-top: 26px;"><i class="fa fa-print"></i> Cetak</button>
                        </div>
                      </div>
                      </form>
                   </div>
                   <div class="col-lg-6">
                     <b>Pilih Periode Export Ke Excel:</b>
                    <hr>
                    <form role="form" method="post" target="_blank" action="./produksi_excel.php">
                      <div class="row">
                        <div class="col-lg-4">
                          <div class="form-group">
                            <label>Bulan</label>
                            <select name="bulan" class="form-control" required="required">
                                  <option value="01">Januari</option>
                                  <option value="02">Februari</option>
                                  <option value="03">Maret</option>
                                  <option value="04">April</option>
                                  <option value="05">Mei</option>
                                  <option value="06">Juni</option>
                                  <option value="07">Juli</option>
                                  <option value="08">Agustus</option>
                                  <option value="09">September</option>
                                  <option value="10">Oktober</option>
                                  <option value="11">November</option>
                                  <option value="12">Desember</option>
                            </select>
                          </div>
                        </div>
                        <div class="col-lg-4">
                          <div class="form-group">
                            <label>Tahun</label>
                            <select name="tahun" class="form-control" required="required">
                                  <?php
                                    $mulai= date('Y') - 50;
                                    for($i = $mulai; $i<$mulai + 100;$i++){
                                      $sel = $i == date('Y') ? ' selected="selected"' : '';
                                      echo '<option value="'.$i.'"'.$sel.'>'.$i.'</option>';
                                    }
                                    ?>
                                  </select>
                          </div>
                        </div>
                       
                        <div class="col-lg-4">
                          <button type="submit" class="btn btn-default" style="margin-top: 26px;"><i class="fa fa-download"></i> Export Ke Excel</button>
                        </div>
                      </div>
                      </form>
                   </div>
                 </div>
                 <hr>
                <table id="example1" class="table table-bordered table-striped">
                  <thead>
                  <tr>
                    <th>No</th>
                    <th>Kode Produksi</th>
                    <th>Tanggal Produksi</th>
                    <th>Ststus Produksi</th>
                    <th>Barang Baku</th>
                    <th>Hasil Produksi</th>
                  </tr>
                  </thead>
                  <tbody>
                    <?php
                      include"koneksi.php";
                      $no=1;
                      $query_pengguna=mysqli_query($konek, "SELECT * FROM tbl_produksi WHERE status_produksi='Produksi Selesai'");
                      while ($data_pengguna=mysqli_fetch_array($query_pengguna)) {?>
                  <tr>
                    <td><?php echo $no;?></td>
                    <td><?php echo $data_pengguna['id_produksi'];?></td>
                    <td><?php echo $data_pengguna['tgl_produksi'];?></td>
                    <td><?php echo $data_pengguna['status_produksi'];?></td>
                    <td>
                      <table class="table">
                        <thead>
                          <tr>
                            <th>No</th>
                            <th>Barang</th>
                            <th>Jumlah</th>
                          </tr>
                        </thead>
                        <tbody>
                          <?php
                            $no_a=1;
                            $query_data_list=mysqli_query($konek, "SELECT * FROM tbl_detail_produksi WHERE id_produksi='".$data_pengguna['id_produksi']."'");
                            while ($data_list_prd=mysqli_fetch_array($query_data_list)) {?>
                          <tr>
                            <td><?php echo $no_a;?></td>
                            <td><?php echo $data_list_prd['nm_barang'];?></td>
                            <td><?php echo $data_list_prd['jumlah_pr'];?> <?php echo $data_list_prd['satuan_pr'];?></td>
                          </tr>
                          <?php $no_a++; }?>
                        </tbody>
                      </table>
                    </td>
                    <td>
                      <table class="table">
                        <thead>
                          <tr>
                            <th>No</th>
                            <th>Barang</th>
                            <th>Jumlah</th>
                          </tr>
                        </thead>
                        <tbody>
                          <?php
                            $no_b=1;
                            $query_hasil=mysqli_query($konek, "SELECT * FROM tbl_hasil_produksi WHERE id_produksi='".$data_pengguna['id_produksi']."'");
                            while ($data_hasil=mysqli_fetch_array($query_hasil)) {?>
                          <tr>
                            <td><?php echo $no_b;?></td>
                            <td><?php echo $data_hasil['nm_barang'];?></td>
                            <td><?php echo $data_hasil['jlh_hasil'];?> <?php echo $data_hasil['satuan_hasil'];?></td>
                          </tr>
                          <?php $no_b++; }?>
                        </tbody>
                      </table>
                    </td>
                  </tr>
                  <?php $no++; }?>
                 
                </tbody>
               
                </table>
              </div>
            </div>
          </div>
        </div>
      </section>
      <!-- /.content -->