<section class="content-header">
        <h1>
          <small>LAPORAN BARANG MASUK</small>
        </h1>
        <ol class="breadcrumb">
          <li><a href="#"><i class="fa fa-dashboard"></i> Dashboard</a></li>
          <li><a href="#">Owner</a></li>
          <li class="active">Laporan Barang Masuk</li>
        </ol>
      </section>
      <section class="content">
        <div class="row">
         
          <div class="col-lg-12">
            <div class="box box-default">
              <div class="box-header with-border" style="overflow: auto;">
                <h3 class="box-title">Laporan Barang Masuk</h3>
              </div>
              <div class="box-body" style="overflow: auto;">
                <div class="row">
                  <div class="col-lg-6">
                    <b>Pilih Periode Cetak Laporan:</b>
                    <hr>
                     <form role="form" method="post" target="_blank" action="./lap_bm.php">
                      <div class="row">
                        <div class="col-lg-4">
                          <div class="form-group">
                            <label for="exampleInputEmail1">Bulan</label>
                            <select name="bulan" class="form-control" required="required">
                                  <option value="01">Januari</option>
                                  <option value="02">Februari</option>
                                  <option value="03">Maret</option>
                                  <option value="04">April</option>
                                  <option value="05">Mei</option>
                                  <option value="06">Juni</option>
                                  <option value="07">Juli</option>
                                  <option value="08">Agustus</option>
                                  <option value="09">September</option>
                                  <option value="10">Oktober</option>
                                  <option value="11">November</option>
                                  <option value="12">Desember</option>
                            </select>
                          </div>
                        </div>
                        <div class="col-lg-4">
                          <div class="form-group">
                            <label for="exampleInputEmail1">Tahun</label>
                            <select name="tahun" class="form-control" required="required">
                                  <?php
                                    $mulai= date('Y') - 50;
                                    for($i = $mulai; $i<$mulai + 100;$i++){
                                      $sel = $i == date('Y') ? ' selected="selected"' : '';
                                      echo '<option value="'.$i.'"'.$sel.'>'.$i.'</option>';
                                    }
                                    ?>
                                  </select>
                          </div>
                        </div>
                       
                        <div class="col-lg-4">
                          <button type="submit" class="btn btn-default" style="margin-top: 26px;"><i class="fa fa-print"></i> Cetak</button>
                        </div>
                      </div>
                      </form>
                   </div>
                   <div class="col-lg-6">
                     <b>Pilih Periode Export Ke Excel:</b>
                    <hr>
                    <form role="form" method="post" target="_blank" action="./bm_excel.php">
                      <div class="row">
                        <div class="col-lg-4">
                          <div class="form-group">
                            <label>Bulan</label>
                            <select name="bulan" class="form-control" required="required">
                                  <option value="01">Januari</option>
                                  <option value="02">Februari</option>
                                  <option value="03">Maret</option>
                                  <option value="04">April</option>
                                  <option value="05">Mei</option>
                                  <option value="06">Juni</option>
                                  <option value="07">Juli</option>
                                  <option value="08">Agustus</option>
                                  <option value="09">September</option>
                                  <option value="10">Oktober</option>
                                  <option value="11">November</option>
                                  <option value="12">Desember</option>
                            </select>
                          </div>
                        </div>
                        <div class="col-lg-4">
                          <div class="form-group">
                            <label>Tahun</label>
                            <select name="tahun" class="form-control" required="required">
                                  <?php
                                    $mulai= date('Y') - 50;
                                    for($i = $mulai; $i<$mulai + 100;$i++){
                                      $sel = $i == date('Y') ? ' selected="selected"' : '';
                                      echo '<option value="'.$i.'"'.$sel.'>'.$i.'</option>';
                                    }
                                    ?>
                                  </select>
                          </div>
                        </div>
                       
                        <div class="col-lg-4">
                          <button type="submit" class="btn btn-default" style="margin-top: 26px;"><i class="fa fa-download"></i> Export Ke Excel</button>
                        </div>
                      </div>
                      </form>
                   </div>
                 </div>
                 <hr>
                <table id="example1" class="table table-bordered table-striped">
                  <thead>
                  <tr>
                    <th>No</th>
                    <th>Tgl. Masuk</th>
                    <th>Barang</th>
                    <th>Jumlah</th>
                    <th>Satuan</th>
                    <th>Harga</th>
                    <th>Total</th>
                   
                  </tr>
                  </thead>
                  <tbody>
                    <?php
                      include"koneksi.php";
                      $no=1;
                      $query_pengguna=mysqli_query($konek, "SELECT * FROM tbl_barang_masuk ORDER BY id_bm DESC");
                      while ($data_pengguna=mysqli_fetch_array($query_pengguna)) {?>
                  <tr>
                    <td><?php echo $no;?></td>
                    <td><?php echo $data_pengguna['tgl_bm'];?></td>
                    <td><?php echo $data_pengguna['nm_barang'];?></td>
                    <td><?php echo $data_pengguna['jumlah_bm'];?></td>
                    <td><?php echo $data_pengguna['satuan_bm'];?></td>
                    <td><?php echo"".number_format($data_pengguna['harga_bm'], 2, ".", ".").""?></td>
                    <td><?php echo"".number_format($data_pengguna['total_bm'], 2, ".", ".").""?></td>
                   
                  </tr>
                  <?php $no++; }?>
                 
                </tbody>
               
                </table>
              </div>
            </div>
          </div>
        </div>
      </section>
      <!-- /.content -->