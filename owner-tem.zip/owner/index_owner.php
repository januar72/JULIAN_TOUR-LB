    <section class="content-header">
        <h1>
          <small>DATA PENGGUNA</small>
        </h1>
        <ol class="breadcrumb">
          <li><a href="#"><i class="fa fa-dashboard"></i> Dashboard</a></li>
          <li><a href="#">Owner</a></li>
          <li class="active">Data Pengguna</li>
        </ol>
      </section>

      <!-- Main content -->
      <section class="content">
        <div class="row">
          
          <div class="col-lg-12">
            <div class="box box-default">
              <div class="box-header with-border">
                <h3 class="box-title">Tabel Data Pengguna</h3>
              </div>
              <div class="box-body" style="overflow: auto;">
                
                 <table id="example1" class="table table-bordered table-striped">
                  <thead>
                  <tr>
                    <th>No</th>
                    <th>Nama</th>
                    <th>No.HP</th>
                    <th>Alamat</th>
                    <th>Username</th>
                    <th>Jabatan</th>
                    <th>Status</th>
                  
                  </tr>
                  </thead>
                  <tbody>
                    <?php
                      include"koneksi.php";
                      $no=1;
                      $query_pengguna=mysqli_query($konek, "SELECT * FROM tbl_users ORDER BY id_user DESC");
                      while ($data_pengguna=mysqli_fetch_array($query_pengguna)) {?>
                  <tr>
                    <td><?php echo $no;?></td>
                    <td><?php echo $data_pengguna['nama_user'];?></td>
                    <td><?php echo $data_pengguna['no_telepon'];?></td>
                    <td><?php echo $data_pengguna['alamat'];?></td>
                    <td><?php echo $data_pengguna['username'];?></td>
                    <td><?php echo $data_pengguna['jabatan'];?></td>
                    <td><?php echo $data_pengguna['status'];?></td>
                    
                  </tr>
                  <?php $no++; }?>
                  <?php 
                    $order="SELECT * FROM tbl_users WHERE status ='Aktif'";
                    $query_order=mysqli_query($konek, $order);
                    $data_order=array();
                    while(($row_order=mysqli_fetch_array($query_order)) !=null){
                    $data_order[]=$row_order;
                    }
                    $count=count($data_order);

                    $order_a="SELECT * FROM tbl_users WHERE status ='Tidak Aktif'";
                    $query_order_a=mysqli_query($konek, $order_a);
                    $data_order_a=array();
                    while(($row_order_a=mysqli_fetch_array($query_order_a)) !=null){
                    $data_order_a[]=$row_order_a;
                    }
                    $count_a=count($data_order_a);
                  ?>
                </tbody>
                <tbody style="font-weight: bold;">
                  <tr>
                    <td colspan="4">Jumlah Pengguna Aktif</td>
                    <td colspan="3"><?php echo $count;?></td>
                  </tr>
                   <tr>
                    <td colspan="4">Jumlah Pengguna Tidak Aktif</td>
                    <td colspan="3"><?php echo $count_a;?></td>
                  </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </section>
      <!-- /.content -->