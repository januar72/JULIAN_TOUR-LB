<section class="content-header">
        <h1>
          <small>LAPORAN DATA BARANG</small>
        </h1>
        <ol class="breadcrumb">
          <li><a href="#"><i class="fa fa-dashboard"></i> Dashboard</a></li>
          <li><a href="#">Owner</a></li>
          <li class="active">Laporan Data Barang</li>
        </ol>
      </section>
      <section class="content">
        <div class="row">
         
          <div class="col-lg-12">
            <div class="box box-default">
              <div class="box-header with-border" style="overflow: auto;">
                <table style="width: 100%;">
                  <tr>
                    <td style="width: 60%;"><h3 class="box-title">Laporan Data Barang</h3></td>
                    <td style="width: 20%; text-align: right;"><a href="./lap_barang.php" class="btn btn-default" target="_blank"><i class="fa fa-print"></i> Cetak</a></td>
                    <td style="width: 20%; text-align: right;"><a href="./barang_excel.php" class="btn btn-default" target="_blank"><i class="fa fa-download"></i> Export Ke Excel</a></td>
                  </tr>
                </table>
               
              </div>
              <div class="box-body" style="overflow: auto;">
                 <table id="example1" class="table table-bordered">
                  <thead>
                  <tr>
                    <th>No</th>
                    <th>Nama Barang</th>
                    <th>Satuan</th>
                    <th>Kategori</th>
                    <th>Stok</th>
                   
                  </tr>
                  </thead>
                  <tbody>
                    <?php
                      include"koneksi.php";
                      $no=1;
                      $query_pengguna=mysqli_query($konek, "SELECT * FROM tbl_barang ORDER BY id_barang DESC");
                      while ($data_pengguna=mysqli_fetch_array($query_pengguna)) {?>
                  <tr>
                    <td><?php echo $no;?></td>
                    <td><?php echo $data_pengguna['nm_barang'];?></td>
                    <td><?php echo $data_pengguna['satuan'];?></td>
                    <td><?php echo $data_pengguna['kategori'];?></td>
                    <td><?php echo $data_pengguna['stok'];?></td>
                   
                  </tr>
                  <?php $no++; }?>
                  <?php 
                    $order="SELECT * FROM tbl_barang WHERE kategori='Barang Baku'";
                    $query_order=mysqli_query($konek, $order);
                    $data_order=array();
                    while(($row_order=mysqli_fetch_array($query_order)) !=null){
                    $data_order[]=$row_order;
                    }
                    $count=count($data_order);

                    $order_a="SELECT * FROM tbl_barang WHERE kategori='Barang Jadi'";
                    $query_order_a=mysqli_query($konek, $order_a);
                    $data_order_a=array();
                    while(($row_order_a=mysqli_fetch_array($query_order_a)) !=null){
                    $data_order_a[]=$row_order_a;
                    }
                    $count_a=count($data_order_a);
                  ?>
                </tbody>
                <tbody style="font-weight: bold;">
                  <tr>
                    <td colspan="3">Jumlah Kategori Barang Baku</td>
                    <td colspan="3"><?php echo $count;?></td>
                  </tr>
                   <tr>
                    <td colspan="3">Jumlah Kategori Barang Jadi</td>
                    <td colspan="3"><?php echo $count_a;?></td>
                  </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </section>
      <!-- /.content -->