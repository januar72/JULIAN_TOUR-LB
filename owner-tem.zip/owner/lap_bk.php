<section class="content-header">
        <h1>
          <small>LAPORAN BARANG KELUAR</small>
        </h1>
        <ol class="breadcrumb">
          <li><a href="#"><i class="fa fa-dashboard"></i> Dashboard</a></li>
          <li><a href="#">Owner</a></li>
          <li class="active">Laporan Barang Keluar</li>
        </ol>
      </section>
      <section class="content">
        <div class="row">
         
          <div class="col-lg-12">
            <div class="box box-default">
              <div class="box-header with-border" style="overflow: auto;">
                <h3 class="box-title">Laporan Barang Keluar</h3>
              </div>
              <div class="box-body" style="overflow: auto;">
                <div class="row">
                  <div class="col-lg-6">
                    <b>Pilih Periode Cetak Laporan:</b>
                    <hr>
                     <form role="form" method="post" target="_blank" action="./lap_bk.php">
                      <div class="row">
                        <div class="col-lg-4">
                          <div class="form-group">
                            <label for="exampleInputEmail1">Bulan</label>
                            <select name="bulan" class="form-control" required="required">
                                  <option value="01">Januari</option>
                                  <option value="02">Februari</option>
                                  <option value="03">Maret</option>
                                  <option value="04">April</option>
                                  <option value="05">Mei</option>
                                  <option value="06">Juni</option>
                                  <option value="07">Juli</option>
                                  <option value="08">Agustus</option>
                                  <option value="09">September</option>
                                  <option value="10">Oktober</option>
                                  <option value="11">November</option>
                                  <option value="12">Desember</option>
                            </select>
                          </div>
                        </div>
                        <div class="col-lg-4">
                          <div class="form-group">
                            <label for="exampleInputEmail1">Tahun</label>
                            <select name="tahun" class="form-control" required="required">
                                  <?php
                                    $mulai= date('Y') - 50;
                                    for($i = $mulai; $i<$mulai + 100;$i++){
                                      $sel = $i == date('Y') ? ' selected="selected"' : '';
                                      echo '<option value="'.$i.'"'.$sel.'>'.$i.'</option>';
                                    }
                                    ?>
                                  </select>
                          </div>
                        </div>
                       
                        <div class="col-lg-4">
                          <button type="submit" class="btn btn-default" style="margin-top: 26px;"><i class="fa fa-print"></i> Cetak</button>
                        </div>
                      </div>
                      </form>
                   </div>
                   <div class="col-lg-6">
                     <b>Pilih Periode Export Ke Excel:</b>
                    <hr>
                    <form role="form" method="post" target="_blank" action="./bk_excel.php">
                      <div class="row">
                        <div class="col-lg-4">
                          <div class="form-group">
                            <label>Bulan</label>
                            <select name="bulan" class="form-control" required="required">
                                  <option value="01">Januari</option>
                                  <option value="02">Februari</option>
                                  <option value="03">Maret</option>
                                  <option value="04">April</option>
                                  <option value="05">Mei</option>
                                  <option value="06">Juni</option>
                                  <option value="07">Juli</option>
                                  <option value="08">Agustus</option>
                                  <option value="09">September</option>
                                  <option value="10">Oktober</option>
                                  <option value="11">November</option>
                                  <option value="12">Desember</option>
                            </select>
                          </div>
                        </div>
                        <div class="col-lg-4">
                          <div class="form-group">
                            <label>Tahun</label>
                            <select name="tahun" class="form-control" required="required">
                                  <?php
                                    $mulai= date('Y') - 50;
                                    for($i = $mulai; $i<$mulai + 100;$i++){
                                      $sel = $i == date('Y') ? ' selected="selected"' : '';
                                      echo '<option value="'.$i.'"'.$sel.'>'.$i.'</option>';
                                    }
                                    ?>
                                  </select>
                          </div>
                        </div>
                       
                        <div class="col-lg-4">
                          <button type="submit" class="btn btn-default" style="margin-top: 26px;"><i class="fa fa-download"></i> Export Ke Excel</button>
                        </div>
                      </div>
                      </form>
                   </div>
                 </div>
                 <hr>
                <table id="example1" class="table table-bordered">
                  <thead>
                  <tr>
                    <th>No</th>
                    <th>Tanggal Keluar</th>
                    <th>Outlet</th>
                    <th>Keterangan</th>
                    <th>List Barang</th>
                   
                  </tr>
                  </thead>
                  <tbody>
                    <?php
                      include"koneksi.php";
                      $no=1;
                      $query_pengguna=mysqli_query($konek, "SELECT * FROM barang_keluar ORDER BY id_bk DESC");
                      while ($data_pengguna=mysqli_fetch_array($query_pengguna)) {

                      $query_outlet_a=mysqli_query($konek, "SELECT * FROM tbl_outlet WHERE id_outlet='".$data_pengguna['id_outlet']."'");
                      $data_outlet_a=mysqli_fetch_array($query_outlet_a);
                    ?>
                  <tr>
                    <td><?php echo $no;?></td>
                    <td><?php echo $data_pengguna['tgl_keluar'];?></td>
                     <td>
                      <?php if ($data_pengguna['id_outlet']=='Lainnya') {
                         echo "-";
                        }else{
                         echo $data_outlet_a['nama_outlet'];
                        }
                      ?>  
                    </td>
                    <td>
                      <?php 
                        
                         echo $data_pengguna['keterangan'];
                        
                      ?>  
                    </td>
                    
                    <td style="padding-top: 0; padding-bottom: 0">
                      <table class="table">
                        <thead>
                          <tr>
                            <th style="padding-top: 0; padding-bottom: 0">No</th>
                            <th style="padding-top: 0; padding-bottom: 0">Barang</th>
                            <th style="padding-top: 0; padding-bottom: 0">Jumlah</th>
                            <th style="padding-top: 0; padding-bottom: 0">Harga</th>
                            <th style="padding-top: 0; padding-bottom: 0">Total Harga</th>
                          </tr>
                        </thead>
                        <tbody>
                          <?php
                            $nolist=1;
                            $query_list=mysqli_query($konek, "SELECT * FROM detail_bk WHERE id_bk='".$data_pengguna['id_bk']."'");
                            while ($data_list=mysqli_fetch_array($query_list)) {
                          ?>
                          <tr>
                            <td style="padding-top: 0; padding-bottom: 0"><?php echo $nolist;?></td>
                            <td style="padding-top: 0; padding-bottom: 0"><?php echo $data_list['nm_barang'];?></td>
                            <td style="padding-top: 0; padding-bottom: 0"><?php echo $data_list['jlh_keluar'];?> <?php echo $data_list['satuan_keluar'];?></td>
                            <td style="padding-top: 0; padding-bottom: 0"><?php echo"".number_format($data_list['harga_keluar'], 2, ".", ".").""?></td>
                            <td style="padding-top: 0; padding-bottom: 0"><?php echo"".number_format($data_list['total_keluar'], 2, ".", ".").""?></td>
                          </tr>
                          <?php $nolist++; }?>
                        </tbody>
                      </table>
                    </td>
                   
                  
                  </tr>
                  <?php $no++; }?>
                 
                </tbody>
               
                </table>
              </div>
            </div>
          </div>
        </div>
      </section>
      <!-- /.content -->