<section class="content-header">
	<h1>
		<small>Data Pemesan</small>
	</h1>
	<ol class="breadcrumb">
		<li><a href=""><i class="fa fa-dashboard"> Dashboard</i></a></li>
		<li><a href="">Admin</a></li>
		<li class="active">Data Pemesan</li>
	</ol>
</section>
<section class="content">
	<div class="row">
		<div class="col-lg-4">
			<div class="box box-default">
				<div class="box-header with-border">
					<h3 class="box-title">Input Data Pemesan Mobil</h3>
				</div>
				<div class="box-body" style="overflow: auto;">
					<form method="post" action="proses_pemesan.php" enctype="multipart/form-data">
						<div class="form-group">
							<label>Nama Lengkap</label>
							<input type="text" name="nama" class="form-control" required>
						</div>
						<div class="form-group">
							<label>No Hp</label>
							<input type="number" name="hp" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Tgl Pesan</label>
							<input type="date" name="tgl_pesan" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Foto Data Diri</label>
							<input type="file" name="fot" class="form-control" required>
						</div>
						<div class="box-footer">
							<input type="submit" name="simpan" class="btn btn-primary">
						</div>
					</form>
				</div>
			</div>
		</div>
		<div class="col-lg-8">
			<div class="box box-default">
				<div class="box-header with-border">
					<h3 class="box-title">Tabel Data Layanan</h3>
				</div>
				<div class="box-body" style="overflow: auto;">
					<table id="example1" class="table table-bordered table-striped">
						<thead>
							<tr>
								<th>No</th>
								<th>Nama</th>
								<th>No Hp</th>
								<th>Tgl Pesan</th>
								<th>Foto Ktp<br>
								<i style="font-size: 8px;">*click</i></th>
								<th>Opsi</th>
							</tr>
						</thead>
						<tbody>
							<?php include 'koneksi.php';
							$no=1;
							$tam=mysqli_query($konek, "SELECT * FROM tb_pes");
							while ($data=mysqli_fetch_array($tam, MYSQLI_ASSOC)) {?>
								<tr>
									<td><?php echo $no++; ?></td>
									<td><?php echo $data['nama']; ?></td>
									<td><?php echo $data['hp']; ?></td>
									<td><?php echo $data['tgl_pesan']; ?></td>
									<td>
										<a href="dashboard_admin.php?p=fot&fot=<?php echo $data['fot']; ?>" class="btn btn-danger" style="padding: 0;">
											<img src="berkas/<?php echo $data['fot']; ?>" style="width: 50px; height:50px;">
										</a>
									</td>
									<td>
										<a href="hapus_pesanan.php?id=<?php echo $data['id_pes']; ?>" class="btn btn-danger btn-xs"><i class="fa fa-trash"></i></a>
									</td>
								</tr>
							<?php } ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</section>