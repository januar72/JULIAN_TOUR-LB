<section class="content-header">
	<h1>
		<small>Input Katalog</small>
	</h1>
	<ol class="breadcrumb">
		<li><a href=""><i class="fa fa-dashboard"> Dashboard</i></a></li>
		<li><a href="">Admin</a></li>
		<li><a href="">Data Katalog</a></li>
	</ol>
</section>
<section class="content">
	<div class="row">
		<div class="col-lg-4">
			<div class="box box-default">
				<div class="box-header with-border">
					<h3 class="box-title">Input Katalog</h3>
				</div>
				<div class="box-body" style="overflow: auto;">
					<form method="post" action="proses_katalog.php" enctype="multipart/form-data">
						<div class="form-group">
							<label>Katalog/Booklet (pdf, min 1 file)</label>
							<input type="file" name="file_catalog" class="form-control" required>
						</div>
						<div class="box-footer">
							<input type="submit" name="simpan" class="btn btn-primary">
						</div>
					</form>
				</div>
			</div>
		</div>
		<div class="col-lg-8">
			<div class="box box-default">
				<div class="box-header with-border">
					<h3 class="box-title">Tabel Katalog</h3>
				</div>
				<div class="box-body" style="overflow: auto;">
					<table id="example1" class="table table-bordered table-striped">
						<thead>
							<tr>
								<th>No</th>
								<th>Booklet/Katalog</th>
								<th>Opsi</th>
							</tr>
						</thead>
						<tbody>
							<?php include 'koneksi.php';
							$no=1;
							$tam=mysqli_query($konek, "SELECT * FROM tb_katalog");
							while ($data=mysqli_fetch_array($tam, MYSQLI_ASSOC)) {?>
								<tr>
									<td><?php echo $no++; ?></td>
									<td><a href="download.php?filename=<?php echo $data['file_catalog']; ?>" class="btn btn-danger">Download</a></td>
									<td>
										<a href="hapus_katalog.php?id=<?php echo $data['id_katalog']; ?>" class="btn btn-danger btn-xs"><i class="fa fa-trash"></i></a>
									</td>
								</tr>
							<?php } ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</section>