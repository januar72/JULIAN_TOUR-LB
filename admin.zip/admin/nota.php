  <!-- Content Header (Page header) -->
      <section class="content-header">
        
      </section>
      <section class="content">
        <div class="row">
          <div class="col-lg-12">
            <div class="box box-default">
              <div class="box-header with-border">
                <h3 class="box-title">Nota</h3>
              </div>
              <div class="box-body" style="width: auto; overflow-x: auto;">
                <?php
                  $nota=$_GET['nota'];
                ?>
                <img src="./nota/<?php echo $nota;?>">
             </div>
            </div>
          </div>
        </div>
      </section>
      <!-- /.content -->