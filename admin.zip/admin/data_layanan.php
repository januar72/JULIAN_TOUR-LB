<section class="content-header">
	<h1>
		<small>Data Layanan</small>
	</h1>
	<ol class="breadcrumb">
		<li><a href=""><i class="fa fa-dashboard"> Dashboard</i></a></li>
		<li><a href="">Admin</a></li>
		<li class="active">Data Layanan</li>
	</ol>
</section>
<section class="content">
	<div class="row">
		<div class="col-lg-4">
			<div class="box box-default">
				<div class="box-header with-border">
					<h3 class="box-title">Input Data Layanan</h3>
				</div>
				<div class="box-body" style="overflow: auto;">
					<form method="post" action="proses_layanan.php" enctype="multipart/form-data">
						<div class="form-group">
							<label>Nama Layanan</label>
							<input type="text" name="nama" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Ket</label>
							<textarea name="ket" class="form-control" cols="3" rows="3"></textarea>
						</div>
						<div class="form-group">
							<label>Foto</label>
							<input type="file" name="gam" class="form-control" required>
						</div>
						<div class="box-footer">
							<input type="submit" name="simpan" class="btn btn-primary">
						</div>
					</form>
				</div>
			</div>
		</div>
		<div class="col-lg-8">
			<div class="box box-default">
				<div class="box-header with-border">
					<h3 class="box-title">Tabel Data Layanan</h3>
				</div>
				<div class="box-body" style="overflow: auto;">
					<table id="example1" class="table table-bordered table-striped">
						<thead>
							<tr>
								<th>No</th>
								<th>Nama</th>
								<th>Ket</th>
								<th>Foto <br>
								<i style="font-size: 8px;">*click</i></th>
								<th>Opsi</th>
							</tr>
						</thead>
						<tbody>
							<?php include 'koneksi.php';
							$no=1;
							$tam=mysqli_query($konek, "SELECT * FROM tb_layanan");
							while ($data=mysqli_fetch_array($tam, MYSQLI_ASSOC)) {?>
								<tr>
									<td><?php echo $no++; ?></td>
									<td><?php echo $data['nama']; ?></td>
									<td><?php echo $data['ket']; ?></td>
									<td>
										<a href="dashboard_admin.php?p=gam&gam=<?php echo $data['gam']; ?>" class="btn btn-danger" style="padding: 0;">
											<img src="berkas/<?php echo $data['gam']; ?>" style="width: 50px; height:50px;">
										</a>
									</td>
									<td>
										<a href="hapus_layanan.php?id=<?php echo $data['id_lynan']; ?>" class="btn btn-danger btn-xs"><i class="fa fa-trash"></i></a>
									</td>
								</tr>
							<?php } ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</section>