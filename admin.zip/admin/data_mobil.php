  <!-- Content Header (Page header) -->
      <section class="content-header">
        <h1>
          <small>DATA MOBIL</small>
        </h1>
        <ol class="breadcrumb">
          <li><a href="#"><i class="fa fa-dashboard"></i> Dashboard</a></li>
          <li><a href="#">Admin</a></li>
          <li class="active">Data Mobil</li>
        </ol>
      </section>
      <section class="content">
        <div class="row">
          <div class="col-lg-3">
            <div class="box box-default">
              <div class="box-header with-border">
                <h3 class="box-title">Form Input Data Mobil</h3>
              </div>
              <div class="box-body">
                <?php
                  if(isset($_GET['notif'])){
                    if($_GET['notif']=="gagal"){
                      echo "
                      <div class='alert alert-danger alert-dismissible' style='text-align:justify; font-size:10px;'>
                      <a href='dashboard_admin.php?p=data_mobil' class='close' style='text-decoration:none'>&times;</a>
                      <h4 style='font-size:12px;'><i class='icon fa fa-ban'></i> Gagal!</h4>
                        Nama barang yang anda masukkan sudah terdaftar....
                      </div>";
                    }
                  }else{
                      echo"";
                  }
                ?>
                <form role="form" method="post" action="proses_simpan_mobil.php" enctype="multipart/form-data">
                  <div class="box-body">
                    <div class="form-group">
                      <label>Nama Mobil</label>
                      <input type="text" class="form-control" name="nama" required="required">
                    </div>
                    
                    <div class="form-group">
                      <label>Harga</label>
                      <input type="text" name="harga" class="form-control" required>
                    </div>

                    <div class="form-group">
                      <label>Deskripsi</label>
                      <textarea name="des" class="form-control" cols="3" rows="4"></textarea>
                    </div>

                    <div class="form-group">
                      <label>Gambar Mobil (1200 x 800)</label>
                      <input type="file" name="gambar" class="form-control" required>
                    </div>

                  </div>
                  <div class="box-footer">
                    <button type="submit" name="simpan" class="btn btn-primary">Submit</button>
                  </div>
                </form>
              </div>
              <!-- /.box-body -->
            </div>
            <!-- /.box -->
          </div>
          <div class="col-lg-9">
            <div class="box box-default">
              <div class="box-header with-border">
                <h3 class="box-title">Tabel Data Barang</h3>
              </div>
              <div class="box-body" style="overflow: auto;">
                <?php
                  if(isset($_GET['notif'])){
                    if($_GET['notif']=="sukses"){
                      echo "
                      <div class='alert alert-success alert-dismissible' style='text-align:justify; font-size:10px;'>
                      <a href='dashboard_admin.php?p=data_mobil' class='close' style='text-decoration:none'>&times;</a>
                      <h4 style='font-size:12px;'><i class='icon fa fa-check'></i> Sukses......</h4>
                        Data Mobil baru berhasil disimpan...
                      </div>";
                    }if($_GET['notif']=="sukses_edit"){
                      echo "
                      <div class='alert alert-success alert-dismissible' style='text-align:justify; font-size:10px;'>
                      <a href='dashboard_admin.php?p=data_mobil' class='close' style='text-decoration:none'>&times;</a>
                      <h4 style='font-size:12px;'><i class='icon fa fa-check'></i> Sukses......</h4>
                        Data Mobil berhasil diedit...
                      </div>";
                    
                     }if($_GET['notif']=="sukses_hapus"){
                      echo "
                      <div class='alert alert-success alert-dismissible' style='text-align:justify; font-size:10px;'>
                      <a href='dashboard_admin.php?p=data_mobil' class='close' style='text-decoration:none'>&times;</a>
                      <h4 style='font-size:12px;'><i class='icon fa fa-check'></i> Sukses......</h4>
                        Data Mobil berhasil dihapus...
                      </div>";
                    }
                  }else{
                      echo"";
                  }
                ?>
                 <table id="example1" class="table table-bordered table-striped">
                  <thead>
                  <tr>
                    <th>No</th>
                    <th>Nama </th>
                    <th>Harga</th>
                    <th>Deskripsi</th>
                    <th>Foto <br>
                      <i style="font-size: 8px;">*click gambar</i>
                    </th>
                    <th>Opsi</th>
                  </tr>
                  </thead>
                  <tbody>
                    <?php
                      include"koneksi.php";
                      $no=1;
                      $query_pengguna=mysqli_query($konek, "SELECT * FROM tb_unit ORDER BY id_unit DESC");
                      while ($data_pengguna=mysqli_fetch_array($query_pengguna)) {?>
                  <tr>
                    <td><?php echo $no;?></td>
                    <td><?php echo $data_pengguna['nama'];?></td>
                    <td><?php echo $data_pengguna['harga'];?></td>
                    <td><?php echo $data_pengguna['des'];?></td>
                    <td>
                      <a href="dashboard_admin.php?p=gambar&gambar=<?php echo $data_pengguna['gambar'] ?>" class="btn btn-primary" style="padding: 0;">
                        <img src="berkas/<?php echo $data_pengguna['gambar']; ?>" style="width: 50px; height: 50px;">
                      </a>
                    </td>
                    <td style="text-align: center;">
                      <a href="proses_hapus_mobil.php?id=<?php echo $data_pengguna['id_unit'];?>" class="btn btn-danger btn-xs"><i class="fa fa-trash"></i></a>
                    </td>
                  </tr>
                  <?php $no++; }?>
                </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </section>
      <!-- /.content -->