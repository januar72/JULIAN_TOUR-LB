  <!-- Content Header (Page header) -->
      <section class="content-header">
        
      </section>
      <section class="content">
        <div class="row">
          <div class="col-lg-12">
            <div class="box box-default">
              <div class="box-header with-border">
                <h3 class="box-title">Maps Full</h3>
              </div>
              <div class="box-body" style="width: auto; overflow-x: auto;">
                <?php
                  $maps=$_GET['maps'];
                ?>
                <img src="<?php echo $maps;?>">
             </div>
            </div>
          </div>
        </div>
      </section>
      <!-- /.content -->