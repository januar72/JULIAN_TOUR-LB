  <!-- Content Header (Page header) -->
      <section class="content-header">
        
      </section>

      <!-- Main content -->
      <section class="content">
            <div class="box box-default">
              <div class="box-header with-border">
                <h3 class="box-title">Form Edit Data Pengguna</h3>
              </div>
              <div class="box-body">
                <?php
                  include"koneksi.php";
                  $id=$_GET['id'];
                  $query_panggil=mysqli_query($konek, "SELECT * FROM tb_user WHERE id_user='$id'");
                  $data_panggil=mysqli_fetch_array($query_panggil);
                ?>
                <form role="form" method="post" action="proses_edit_pengguna.php?id=<?php echo $id;?>">
                  <div class="box-body">
                      <div class="row">
                        <div class="col-lg-4">
                          <div class="form-group">
                            <label>Nama</label>
                            <input type="text" class="form-control" value="<?php echo $data_panggil['nama'];?>" name="nama" required="required">
                          </div>
                        </div>
                        <div class="col-lg-4">
                         <div class="form-group">
                          <label>Jabatan</label>
                          <select name="jabatan" required="required" class="form-control">
                            <option value="Admin">Admin</option>
                            <option value="Owner">Owner</option>
                          </select>
                          </div>
                        </div>
                        <div class="col-lg-4">
                         <div class="form-group">
                          <label>Status Aktif</label>
                          <select name="status" required="required" class="form-control">
                            <option value="Aktif">Aktif</option>
                            <option value="Tidak Aktif">Tidak Aktif</option>
                          </select>
                          </div>
                        </div>
                    </div>
                  </div>
                  <div class="box-footer">
                    <button type="submit" class="btn btn-primary">Submit</button>
                  </div>
                </form>
              </div>
              <!-- /.box-body -->
            </div>
          
      </section>
      <!-- /.content -->