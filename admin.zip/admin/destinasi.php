<section class="content-header">
	<h1>
		<small>Data Destinasi Wisata</small>
	</h1>
	<ol class="breadcrumb">
		<li><a href=""><i class="fa fa-dashboard"> Dashboard</i></a></li>
		<li><a href="">Admin</a></li>
		<li class="active">Data Destinasi</li>
	</ol>
</section>
<section class="content">
	<div class="row">
		<div class="col col-lg-4">
			<div class="box box-default">
				<div class="box-header with-border">
					<h3 class="box-title">Input Data Destinasi</h3>
				</div>
				<div class="box-body" style="overflow: auto;">
					<form method="post" action="proses_destinasi.php" enctype="multipart/form-data">
						<div class="form-group">
							<label>Nama Tempat Wisata</label>
							<textarea name="nama" class="form-control" cols="3" rows="3"></textarea>
						</div>
						<div class="form-group">
							<label>Deskripsi</label>
							<textarea name="des" class="form-control" cols="3" rows="4" required></textarea>
						</div>
						<div class="form-group">
							<label>Foto Wisata(899 x 594)</label>
							<input type="file" name="foto" class="form-control" required>
						</div>
						<div class="box-footer">
							<input type="submit" name="simpan" class="btn btn-primary">
						</div>
					</form>
				</div>
			</div>
		</div>
		<div class="col-lg-8">
			<div class="box box-default">
				<div class="box-header with-border">
					<h3 class="box-title">Tabel Destinasi</h3>
				</div>
				<div class="box-body" style="overflow: auto;">
					<table id="example1" class="table table-bordered table-striped">
						<thead>
							<tr>
								<th>No</th>
								<th>Nama Wisata</th>
								<th>Deskripsi</th>
								<th><br>
									<i style="font-size: 8px;">*click gambar</i>
								</th>
								<th>Opsi</th>
							</tr>
						</thead>
						<tbody>
							<?php include 'koneksi.php';
							$no =1;
							$tam=mysqli_query($konek, "SELECT * FROM tb_dest");
							while ($data=mysqli_fetch_array($tam, MYSQLI_ASSOC)) {?>
								<tr>
									<td><?php echo $no++; ?></td>
									<td><?php echo $data['nama']; ?></td>
									<td><?php echo $data['des']; ?></td>
									<td>
										<a href="dashboard_admin.php?p=foto&foto=<?php echo $data['foto']; ?>" class="btn btn-primary" style="padding: 0;">
											<img src="berkas/<?php echo $data['foto']; ?>" style="width: 50px; height:50px;">
										</a>
									</td>
									<td>
										<a href="hapus_wisata.php?id=<?php echo $data['id_dest']; ?>"><i class="fa fa-trash"></i></a>
									</td>
								</tr>
							<?php } ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</section>