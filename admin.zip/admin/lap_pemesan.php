
  <section class="content-header">
        <h1>
          <small>LAPORAN DATA PEMESAN MOBIL</small>
        </h1>
        <ol class="breadcrumb">
          <li><a href="#"><i class="fa fa-dashboard"></i> Dashboard</a></li>
          <li><a href="#">Admin</a></li>
          <li class="active">Laporan Data Pemesan</li>
        </ol>
      </section>
      <section class="content">
        <div class="row">
         
          <div class="col-lg-12">

             <div class="box">
              <div class="box-header d-flex p-0">
                
                <ul class="nav nav-pills ml-auto p-2">
                  <li class="nav-item"><a class="nav-link active" href="#tab_1" data-toggle="tab"><i class="fa fa-print"></i> Laporan Pemesan Per Hari</a></li>
                  <li class="nav-item"><a class="nav-link" href="#tab_2" data-toggle="tab"><i class="fa fa-print"></i> Laporan Pemesan Per Bulan</a></li>
                </ul>
              </div><!-- /.card-header -->
              <div class="box-body">
                <div class="tab-content">
                  <div class="tab-pane active" id="tab_1">
                     <form role="form" method="post" target="_blank" action="./lap_pngj_a.php">
                      <div class="row">
                        <div class="col-lg-5">
                          <div class="form-group">
                            <label for="exampleInputEmail1">Tanggal Awal</label>
                            <input type="date" name="ta" class="form-control" required>
                          </div>
                        </div>
                        <div class="col-lg-5">
                         <div class="form-group">
                            <label for="exampleInputEmail1">Tanggal Akhir</label>
                            <input type="date" name="tak" class="form-control" required>
                          </div>
                        </div>
                       
                        <div class="col-lg-1">
                          <button type="submit" class="btn btn-default" style="margin-top: 26px;"><i class="fa fa-print"></i> Cetak</button>
                        </div>
                      </div>
                      </form>
                  </div>
                  <!-- /.tab-pane -->
                  <div class="tab-pane" id="tab_2">
                     <form role="form" method="post" target="_blank" action="./lap_pngj.php">
                      <div class="row">
                        <div class="col-lg-5">
                          <div class="form-group">
                            <label for="exampleInputEmail1">Bulan</label>
                            <select name="bulan" class="form-control" required="required">
                                  <option value="01">Januari</option>
                                  <option value="02">Februari</option>
                                  <option value="03">Maret</option>
                                  <option value="04">April</option>
                                  <option value="05">Mei</option>
                                  <option value="06">Juni</option>
                                  <option value="07">Juli</option>
                                  <option value="08">Agustus</option>
                                  <option value="09">September</option>
                                  <option value="10">Oktober</option>
                                  <option value="11">November</option>
                                  <option value="12">Desember</option>
                            </select>
                          </div>
                        </div>
                        <div class="col-lg-5">
                          <div class="form-group">
                            <label for="exampleInputEmail1">Tahun</label>
                            <select name="tahun" class="form-control" required="required">
                                  <?php
                                    $mulai= date('Y') - 50;
                                    for($i = $mulai; $i<$mulai + 100;$i++){
                                      $sel = $i == date('Y') ? ' selected="selected"' : '';
                                      echo '<option value="'.$i.'"'.$sel.'>'.$i.'</option>';
                                    }
                                    ?>
                                  </select>
                          </div>
                        </div>
                       
                        <div class="col-lg-1">
                          <button type="submit" class="btn btn-default" style="margin-top: 26px;"><i class="fa fa-print"></i> Cetak</button>
                        </div>
                      </div>
                      </form>
                  </div>
                  <!-- /.tab-pane -->
                  
                  <!-- /.tab-pane -->
                </div>
                <!-- /.tab-content -->
              </div><!-- /.card-body -->
            </div>

            <div class="box box-default">
              <div class="box-header with-border" style="overflow: auto;">
                <table style="width: 100%;">
                </table>
               
              </div>
              <div class="box-body" style="overflow: auto;">
                 <table id="example1" class="table table-bordered">
                  <thead>
                  <tr>
                    <th>No</th>
                    <th>Nama </th>
                    <th>No hp</th>
                    <th>Tgl Pesan</th>
                    <th>Foto Ktp</th>
                   
                  </tr>
                  </thead>
                  <tbody>
                    <?php
                      include"koneksi.php";
                      $no=1;
                      $query_pengguna=mysqli_query($konek, "SELECT * FROM tb_pes ORDER BY id_pes DESC");
                      while ($data_pengguna=mysqli_fetch_array($query_pengguna)) {?>
                  <tr>
                    <td><?php echo $no;?></td>
                    <td><?php echo $data_pengguna['nama'];?></td>
                    <td><?php echo $data_pengguna['hp']; ?></td>
                    <td><?php echo $data_pengguna['tgl_pesan']; ?></td>
                    <td>
                      <img src="berkas/<?php echo $data_pengguna['fot']; ?>" style="width: 50px; height: 50px;">
                    </td>
                   
                  </tr>
                  <?php $no++; }?>
                  <?php 
                    $order_a="SELECT * FROM tb_pes";
                    $query_order_a=mysqli_query($konek, $order_a);
                    $data_order_a=array();
                    while(($row_order_a=mysqli_fetch_array($query_order_a)) !=null){
                    $data_order_a[]=$row_order_a;
                    }
                    $count_a=count($data_order_a);
                  ?>
                </tbody>
                <tbody style="font-weight: bold;">
                   <tr>
                    <td colspan="1">Jumlah Pemesan</td>
                    <td colspan="1"><?php echo $count_a;?> Orang</td>
                  </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </section>
      <!-- /.content -->