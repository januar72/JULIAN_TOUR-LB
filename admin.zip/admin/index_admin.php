    <section class="content-header">
        <h1>
          <small>DATA PENGGUNA</small>
        </h1>
        <ol class="breadcrumb">
          <li><a href="#"><i class="fa fa-dashboard"></i> Dashboard</a></li>
          <li><a href="#">Admin</a></li>
          <li class="active">Data Pengguna</li>
        </ol>
      </section>

      <!-- Main content -->
      <section class="content">
        <div class="row">
          <div class="col-lg-3">
            <div class="box box-default">
              <div class="box-header with-border">
                <h3 class="box-title">Form Input Data Pengguna</h3>
              </div>
              <div class="box-body" style="overflow: auto;">
                <?php
                  if(isset($_GET['notif'])){
                    if($_GET['notif']=="gagal"){
                      echo "
                      <div class='alert alert-danger alert-dismissible' style='text-align:justify; font-size:10px;'>
                      <a href='dashboard_admin.php?index_admin' class='close' style='text-decoration:none'>&times;</a>
                      <h4 style='font-size:12px;'><i class='icon fa fa-ban'></i> Gagal!</h4>
                        Proses simpan data gagal, Username yang anda masukkan sudah digunakan oleh pengguna lain. Silahkan masukkan Username yang berbeda
                      </div>";
                    }
                  }else{
                      echo"";
                  }
                ?>
                <form role="form" method="post" action="proses_simpan_pengguna.php">
                  <div class="box-body">
                    <div class="form-group">
                      <label>Nama</label>
                      <input type="text" class="form-control" name="nama" required="required">
                    </div>
                     <div class="form-group">
                      <label>Jabatan</label>
                      <select name="jabatan" required="required" class="form-control">
                        <?php
                          $cek_jabatan = mysqli_query($konek, "SELECT * FROM tbl_users WHERE jabatan='Owner' AND status='Aktif'");
                          $result_jabatan = mysqli_num_rows($cek_jabatan);
                          $data_jabatan = mysqli_fetch_array($cek_jabatan);
                          if ($result_jabatan > 0) {
                            echo"<option value='Admin'>Admin</option>";
                          }elseif($result_jabatan == 0){
                            echo"<option value='Owner'>Owner</option>
                            <option value='Admin'>Admin</option>";
                          } ?>
                       
                      </select>
                    </div>
                    <div class="form-group">
                      <label>Uusername</label>
                      <input type="text" class="form-control" name="username" required="required">
                    </div>
                    <div class="form-group">
                      <label>Password</label>
                      <input type="password" class="form-control" name="password" required="required">
                    </div>
                  </div>
                  <div class="box-footer">
                    <button type="submit" name="simpan" class="btn btn-primary">Submit</button>
                  </div>
                </form>
              </div>
              <!-- /.box-body -->
            </div>
            <!-- /.box -->
          </div>
          <div class="col-lg-9">
            <div class="box box-default">
              <div class="box-header with-border">
                <h3 class="box-title">Tabel Data Pengguna</h3>
              </div>
              <div class="box-body" style="overflow: auto;">
                <?php
                  if(isset($_GET['notif'])){
                    if($_GET['notif']=="sukses"){
                      echo "
                      <div class='alert alert-success alert-dismissible' style='text-align:justify; font-size:10px;'>
                      <a href='dashboard_admin.php?index_admin' class='close' style='text-decoration:none'>&times;</a>
                      <h4 style='font-size:12px;'><i class='icon fa fa-check'></i> Sukses......</h4>
                        Data pengguna berhasil disimpan...
                      </div>";
                    }if($_GET['notif']=="sukses_edit"){
                      echo "
                      <div class='alert alert-success alert-dismissible' style='text-align:justify; font-size:10px;'>
                      <a href='dashboard_admin.php?index_admin' class='close' style='text-decoration:none'>&times;</a>
                      <h4 style='font-size:12px;'><i class='icon fa fa-check'></i> Sukses......</h4>
                        Data pengguna berhasil diedit...
                      </div>";
                    }
                  }else{
                      echo"";
                  }
                ?>
                 <table id="example1" class="table table-bordered table-striped">
                  <thead>
                  <tr>
                    <th>No</th>
                    <th>Nama</th>
                    <th>Username</th>
                    <th>Jabatan</th>
                    <th>Status</th>
                    <th>Opsi</th>
                  </tr>
                  </thead>
                  <tbody>
                    <?php
                      include"koneksi.php";
                      $no=1;
                      $query_pengguna=mysqli_query($konek, "SELECT * FROM tb_user ORDER BY id_user DESC");
                      while ($data_pengguna=mysqli_fetch_array($query_pengguna)) {?>
                  <tr>
                    <td><?php echo $no;?></td>
                    <td><?php echo $data_pengguna['nama'];?></td>
                    <td><?php echo $data_pengguna['username'];?></td>
                    <td><?php echo $data_pengguna['jabatan'];?></td>
                    <td><?php echo $data_pengguna['status'];?></td>
                    <td>
                      <?php
                        $data = mysqli_fetch_array(mysqli_query($konek, "SELECT * FROM tb_user  WHERE username='$_SESSION[masuk]'")); 
                        if ( $data_pengguna['id_user']==$data['id_user']) {
                          echo"";
                        }else{?>
                          <a href="dashboard_admin.php?p=edit_pengguna&id=<?php echo $data_pengguna['id_user'];?>" class="btn btn-primary btn-xs"><i class="fa fa-edit"></i></a>
                        <?php }?>
                    </td>
                  </tr>
                  <?php $no++; }?>
                  <?php 
                    $order="SELECT * FROM tb_user WHERE status ='Aktif'";
                    $query_order=mysqli_query($konek, $order);
                    $data_order=array();
                    while(($row_order=mysqli_fetch_array($query_order)) !=null){
                    $data_order[]=$row_order;
                    }
                    $count=count($data_order);

                    $order_a="SELECT * FROM tb_user WHERE status ='Tidak Aktif'";
                    $query_order_a=mysqli_query($konek, $order_a);
                    $data_order_a=array();
                    while(($row_order_a=mysqli_fetch_array($query_order_a)) !=null){
                    $data_order_a[]=$row_order_a;
                    }
                    $count_a=count($data_order_a);
                  ?>
                </tbody>
                <tbody style="font-weight: bold;">
                  <tr>
                    <td colspan="4">Jumlah Pengguna Aktif</td>
                    <td colspan="4"><?php echo $count;?></td>
                  </tr>
                   <tr>
                    <td colspan="4">Jumlah Pengguna Tidak Aktif</td>
                    <td colspan="4"><?php echo $count_a;?></td>
                  </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </section>
      <!-- /.content -->