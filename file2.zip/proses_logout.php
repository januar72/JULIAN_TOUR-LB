<?php
 session_start();
 unset($_SESSION['masuk']);
 echo "<script>alert('Proses logout sukses....');
 document.location.href='login.php'</script>\n";
?>
