<?php 
include 'koneksi.php';
if (isset($_POST['simpan'])) {
	$nama =$_POST['nama'];
	$jabatan =$_POST['jabatan'];
	$username =$_POST['username'];
	$password =$_POST['password'];

$simpan =mysqli_query($konek, "INSERT INTO `tb_user` (`id_user`,`nama`,`jabatan`,`username`,`password`,`status`) VALUES (null, '$nama','$jabatan','$username','$password','Aktif')");
header("location:dashboard_admin.php?p=index_admin&notif=sukses");
}
 ?>