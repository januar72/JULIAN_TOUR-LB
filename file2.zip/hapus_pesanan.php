<?php 
include 'koneksi.php';

$id =$_GET['id'];

$hapus=mysqli_query($konek, "DELETE FROM tb_pes WHERE id_pes='$id'");
header("Location:dashboard_admin.php?p=data_pemesan");
 ?>