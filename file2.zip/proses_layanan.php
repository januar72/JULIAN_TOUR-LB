<?php 
include 'koneksi.php';
if (isset($_POST['simpan'])) {
	$direktori ="berkas/";
	$file_name =$_FILES['gam']['name'];
	move_uploaded_file($_FILES['gam']['tmp_name'],$direktori.$file_name);

	$nama =$_POST['nama'];
	$ket =$_POST['ket'];

$simpan=mysqli_query($konek, "INSERT INTO `tb_layanan` (`id_lynan`,`nama`,`ket`,`gam`) VALUES (null, '$nama','$ket','$file_name')");

header("Location:dashboard_admin.php?p=data_layanan");
}
 ?>