<?php include 'tem/header.php'; ?>
        <div class="breadcrumbs">
            <div class="wrap">
                <div class="wrap_float">
                    <a href="index.php">Home</a>
                    <span class="separator">/</span>
                    <a href="#" class="current">Rental Mobil</a>
                </div>
            </div>
        </div>
        <div class="image_bg--single" style="background-image: url(depan/aset/img/vput.jpg);"></div>
        <div class="page_content single-page tour-single">
            <div class="content-head">
                <div class="wrap">
                    <div class="wrap_float">
                        <div class="main">
                            <div class="section-top single-row">
                                <div class="single-left">
                                    <h1 class="title">
                                        Labuan Bajo Manggarai Barat NTT
                                    </h1>
                                    <div class="geo">NTT</div>
                                </div>
                                <div class="single-right controls">
                                    <button class="btn getModal" data-href="#book-now"><span>Pesan Sekarang</span></button>
                                    <div class="slick-arrows tour-single-arrows">
                                        <div class="arrow prev"></div>
                                        <div class="arrow next"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="single-tour-slider" id="single-tour-slider">
                                <?php include 'koneksi.php';
                                $tampil_a=mysqli_query($konek, "SELECT * FROM tb_unit");
                                while ($data=mysqli_fetch_array($tampil_a,MYSQLI_ASSOC)) {?>
                                <div class="single-tour-slide">
                                    <img src="berkas/<?php echo $data['gambar']; ?>" class="image-cover" alt="">
                                </div>
                            <?php } ?>
                            </div>
                            <div class="description single-row">
                                <div class="single-left">
                                    <?php include 'koneksi.php';
                                        $id =$_GET['id'];
                                            $data_tam= mysqli_fetch_array(mysqli_query($konek, "SELECT * FROM tb_unit")); ?>
                                    <p>
                                      Beragam pilihan kendaraan, siap diandalkan untuk apapun kebutuhan Anda, mulai dari perjalanan bisnis, liburan bersama keluarga, maupun kebutuhan pribadi. Sewa mobil dengan unit berusia muda yang rutin mendapatkan perawatan dan pemeliharaan untuk pengalaman terbaik. tentunya membuat perjalanan Anda menjadi lebih aman dan nyaman.
                                    </p>
                                </div>
                                <div class="single-right">
                                    <div class="map-iframe">
                                        <?php include 'koneksi.php';
                                        $data_a=mysqli_query($konek, "SELECT * FROM tb_soc");
                                        while ($data=mysqli_fetch_array($data_a, MYSQLI_ASSOC)) {?>
                                        <iframe src="<?php echo $data['maps']; ?>" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                                        <?php } ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="content-body">
                <div class="wrap">
                    <div class="wrap_float">
                        <div class="single-left">
                            <div class="single-content page--content details">
                                <h2>Detail Mobil</h2>
                                <?php include 'koneksi.php';
                                $id =$_GET['id'];
                                $data_tam= mysqli_fetch_array(mysqli_query($konek, "SELECT * FROM tb_unit")); ?>
                                <p><?php echo $data_tam['des']; ?></p>
                                <div class="list-block">
                                    <ul class="true">
                                        <li>Free Driver</li>
                                        <li>Service Rutin</li>
                                        <li>Lepas Kunci</li>
                                    </ul>
                                    <ul class="true">
                                        <li>Free BBM</li>
                                        <li>Harga Terjangkau</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="single-right">
                            <div class="single-sidebar">
                                <?php include 'koneksi.php';
                                $id =$_GET['id'];
                                $data_b= mysqli_fetch_array(mysqli_query($konek, "SELECT * FROM tb_unit WHERE id_unit='$id'")); ?>
                                <div class="tour--info">
                                    <div class="top" style="background-image: url(berkas/<?php echo $data_b['gambar']; ?>);">
                                       
                                        <!-- <div class="tags">
                                            <div class="tag discount">20% off</div>
                                            <div class="tag new">New</div>
                                        </div> -->
                                       
                                        <div class="flex-bottom">
                                            <div class="_title"><?php echo $data_b['nama']; ?></div>
                                            <div class="time">1 hari</div>
                                        </div>
                                    </div>
                                    <div class="bottom">
                                        <div class="cost">
                                            <div class="new-cost">Rp. <?php echo number_format($data_b['harga'],2,'.','.'); ?></div>
                                            <!-- <div class="old-cost">$3,880</div> -->
                                        </div>
                                        <button class="btn getModal" data-href="#book-now">
                                            Pesan
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="mobile-fixed-bottom getModal" data-href="#book-now">
                Book now
            </div>
        </div>
<?php include 'tem/footer.php'; ?>