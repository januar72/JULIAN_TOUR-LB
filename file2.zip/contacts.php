<?php echo include 'tem/header.php'; ?>
        <div class="breadcrumbs">
            <div class="wrap">
                <div class="wrap_float">
                    <a href="index.html">Home</a>
                    <span class="separator">/</span>
                    <a href="contacts.html" class="current">Kontak</a>
                </div>
            </div>
        </div>
        <div class="page_content single-page about-page contacts-page">
            <div class="content-head">
                <div class="wrap">
                    <div class="wrap_float">
                        <div class="main">
                            <div class="title">
                                Kontak Kami
                            </div>
                            <div class="contacts-columns">
                                <div class="column tel">
                                    <div class="_title">No Hp</div>
                                    <div class="text">
                                        Segera hubungi kami lewat no hp yang tertera di bawah ini.
                                    </div>
                                    <?php include 'koneksi.php';
                                    $tamp=mysqli_query($konek, "SELECT * FROM tb_soc");
                                    while ($data=mysqli_fetch_array($tamp, MYSQLI_ASSOC)) {?>
                                    <a href="#"><?php echo $data['hp']; ?></a>
                                    <?php } ?>
                                </div>
                                <div class="column email">
                                    <div class="_title">Email</div>
                                    <div class="text">
                                        Segera Hubungi kami lewat email
                                    </div>
                                    <?php include 'koneksi.php';
                                    $ta=mysqli_query($konek, "SELECT * FROM tb_soc");
                                    while ($data=mysqli_fetch_array($ta, MYSQLI_ASSOC)) {?>
                                    <a href="#"><?php echo $data['email']; ?></a>
                                    <?php } ?>
                                </div>
                                <div class="column location">
                                    <div class="_title">Lokasi</div>
                                    <div class="text">
                                        Jln.Pisang Susu Labuan Bajo NTT
                                    </div>
                                    <a href="#">Lihat Maps</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="content-body">
                <div class="mab-block" id="">
                    <?php include 'koneksi.php';
                    $tam=mysqli_query($konek, "SELECT * FROM tb_soc");
                    while ($data_a=mysqli_fetch_array($tam, MYSQLI_ASSOC)) {?>
                    <iframe src="<?php echo $data_a['maps']; ?>" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                <?php } ?>
                </div>
            </div>
        </div>
<?php include 'tem/footer.php'; ?>