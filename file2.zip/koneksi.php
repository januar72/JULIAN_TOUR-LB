<?php 
$host="localhost";
$user="root";
$password="";
$database="db_jk";

$konek=mysqli_connect($host, $user, $password, $database);

?>