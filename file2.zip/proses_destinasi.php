<?php 
include 'koneksi.php';
if (isset($_POST['simpan'])) {
	$direktori ="berkas/";
	$file_name =$_FILES['foto']['name'];
	move_uploaded_file($_FILES['foto']['tmp_name'],$direktori.$file_name);

	$nama =$_POST['nama'];
	$des =$_POST['des'];

$simpan_data=mysqli_query($konek, "INSERT INTO `tb_dest` (`id_dest`,`nama`,`des`,`foto`) VALUES (null, '$nama','$des','$file_name')");

header("location:dashboard_admin.php?p=destinasi&notif=sukses");
}
 ?>
