<?php 
include 'koneksi.php';

  $file_name =htmlspecialchars($_FILES['file_catalog']['name']);
  $tmp =htmlspecialchars($_FILES['file_catalog']['tmp_name']);
  $path ="./berkas/".$file_name;
  move_uploaded_file($tmp, $path);

  $simpan =mysqli_query($konek, "INSERT INTO `tb_katalog` (`id_katalog`,`file_catalog`) VALUES (null, '$file_name')");
 
 header("Location:dashboard_admin.php?p=katalog&notif=sukses");
 ?>