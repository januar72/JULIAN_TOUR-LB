<?php include 'tem/header.php'; ?>
        <div class="breadcrumbs">
            <div class="wrap">
                <div class="wrap_float">
                    <a href="index.php">Home</a>
                    <span class="separator">/</span>
                    <a href="#" class="current">About Us</a>
                </div>
            </div>
        </div>
        <div class="page_content single-page about-page">
            <div class="content-head">
                <div class="wrap">
                    <div class="wrap_float">
                        <div class="main">
                            <div class="section-top">
                                <div class="title">
                                    About Us
                                </div>
                                <div class="slick-arrows about-slider-arrows">
                                    <div class="arrow prev"></div>
                                    <div class="arrow next"></div>
                                </div>
                            </div>
                            <div class="about-slider" id="about-slider">
                                <div class="about-slide">
                                    <img src="depan/aset/img/about1.jpeg" alt="" class="image-cover">
                                </div>
                                <div class="about-slide">
                                    <img src="depan/aset/img/about2.jpeg" alt="" class="image-cover">
                                </div>
                                <div class="about-slide">
                                    <img src="depan/aset/img/about3.jpeg" alt="" class="image-cover">
                                </div>
                            </div>
                            <div class="description">
                                <div class="description-title">
                                    Tentang Kami
                                </div>
                                <div class="text">
                                    <div class="left">
                                        <p>
                                           Beragam pilihan kendaraan, siap diandalkan untuk apapun kebutuhan Anda, mulai dari perjalanan bisnis, liburan bersama keluarga, maupun kebutuhan pribadi. Sewa mobil dengan unit berusia muda yang rutin mendapatkan perawatan dan pemeliharaan untuk pengalaman terbaik. tentunya membuat perjalanan Anda menjadi lebih aman dan nyaman.
                                        </p>
                                        <p>
                                           Layanan Kami sangat memenuhi kebutuhan mobilitas bisnis Anda secara menyeluruh dengan berbagai solusi transportasi, mulai dari rental mobil jangka pendek dan panjang, dengan sistem pengelolaan armada yang sangat signifikan
                                        </p>
                                    </div>
                                    <div class="right">
                                        <p>
                                            Layanan Terbaik Memberikan fasilitas dan kenyamanan terbaik juga.
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
<?php include 'tem/footer.php'; ?>