<?php include 'tem/header.php'; ?>
        <div class="homepage_slider">
            <div class="slider-container">
                <div class="slider-control left inactive"></div>
                <div class="slider-control right"></div>
                <ul class="slider-pagi"></ul>
                <div class="slider">
                    <div class="slide slide-0 active">
                        <div class="slide__bg" style="background-image: url(depan/aset/img/slide.jpg);"></div>
                        <div class="slide__content">
                            <div class="slide__text">
                                <h2 class="slide__text-heading">Mobil Alphard</h2>
                                <p class="slide__text-desc">
                                    Segera Pesan Mobil Kesukaan Kamu
                                </p>
                                <div class="slide__controls">
                                    <?php include 'koneksi.php';
                                    $cari_a=mysqli_fetch_array(mysqli_query($konek, "SELECT * FROM tb_unit"));
                                     ?>
                                    <a href="single.php?id=<?php echo $cari_a['id_unit']; ?>" class="btn">Rental Mobil</a>


                                    <a href="destinations.php" class="btn btn__choose_tour">Kunjungi</a>
                                    <a class="arrow next"></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="slide slide-1 ">
                        <div class="slide__bg" style="background-image: url(depan/aset/img/name.jpeg);"></div>
                        <div class="slide__content">
                            <div class="slide__text">
                                <h2 class="slide__text-heading">Mobil Fortuner </h2>
                                <p class="slide__text-desc">Segera Pesan Mobil Kesukaan Kamu</p>
                                <div class="slide__controls">
                                    <?php include 'koneksi.php';
                                    $cari_a=mysqli_fetch_array(mysqli_query($konek, "SELECT * FROM tb_unit"));
                                     ?>
                                    <a href="single.php?id=<?php echo $cari_a['id_unit']; ?>" class="btn">Rental Mobil</a>

                                    <a href="destinations.php" class="btn btn__choose_tour">Kunjungi</a>
                                    <a class="arrow next"></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="most_popular">
                <span>
                   Wae Kelambu, Kec. Komodo, Kabupaten Manggarai Barat, Nusa Tenggara Timur.
                </span>
            </div>

        </div>
        <div class="most_popular__section mainpage-slider">
            <div class="wrap">
                <div class="wrap_float">
                    <div class="top_part">
                        <div class="top_part_left">
                            <p class="section_subtitle">POPULER</p>
                            <h2 class="section_title">
                                Kunjungan <br>Libur Paling Populer
                            </h2>
                        </div>
                        <div class="top_part_right">
                            <a href="tour-list.html" class="btn">
                                <span>Lihat Selengkapnya</span>
                            </a>
                            <div class="controls" id="most_popular__arrows">
                                <div class="arrow prev"></div>
                                <div class="arrow next"></div>
                            </div>
                        </div>
                    </div>
                    <div class="most_popular__section__slider" id="most_popular__slider">
                        <a href="destinations.php" class="slider_item" style="background-image: url(depan/aset/img/prevput1.jpeg)">
                            <div class="slider_item__content">
                                <h3 class="title">
                                    Labuan Bajo | Manggarai Barat NTT 
                                </h3>
                                <p class="description">
                                    jelajahi tempat terindah ini dan habiskan waktu liburan Mu bersama sahabat atau keluarga.
                                </p>
                                <div class="days">
                                    <span>1 hari</span>
                                </div>
                            </div>
                        </a>

                        <a href="destinations.php" class="slider_item" style="background-image: url(depan/aset/img/prevput2.jpeg)">
                            <!-- <div class="slider_item__tags">
                                <div class="tag discount">20% off</div>
                            </div> -->
                            <div class="slider_item__content">
                                <h3 class="title">
                                    Labuan Bajo | Manggarai Barat NTT 
                                </h3>
                                <p class="description">
                                    jelajahi tempat terindah ini dan habiskan waktu liburan Mu bersama sahabat atau keluarga.
                                </p>
                                <div class="days">
                                    <span>1 hari</span>
                                </div>
                            </div>
                        </a>

                        <a href="destinations.php" class="slider_item" style="background-image: url(depan/aset/img/prevput3.jpeg)">
                            <div class="slider_item__content">
                                <h3 class="title">
                                    Labuan Bajo | Manggarai Barat NTT 
                                </h3>
                                <p class="description">
                                    jelajahi tempat terindah ini dan habiskan waktu liburan Mu bersama sahabat atau keluarga.
                                </p>
                                <div class="days">
                                    <span>1 hari</span>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <div class="benefits">
            <div class="wrap">
                <div class="wrap_float">
                    <?php include 'koneksi.php';
                    $tampil_dat=mysqli_query($konek, "SELECT * FROM tb_layanan");
                    while ($data_ab=mysqli_fetch_array($tampil_dat, MYSQLI_ASSOC)) {?>
                    <div class="item">
                        <div class="item_img">
                            <img src="berkas/<?php echo $data_ab['gam']; ?>" alt="">
                        </div>
                        <div class="tc">
                            <h3 class="item_title"><?php echo $data_ab['nama']; ?></h3>
                            <p class="item_text">
                                <?php echo $data_ab['ket']; ?>
                            </p>
                        </div>
                    </div>
                <?php } ?>
                </div>
            </div>
        </div>


        <div class="popular_destination__section mainpage-slider">
            <div class="wrap">
                <div class="wrap_float">
                    <div class="top_part">
                        <div class="top_part_left">
                            <div class="section_subtitle">
                                Rental Mobil
                            </div>
                            <h2 class="section_title">
                                Pilih Mobil Kesukaan.
                            </h2>
                        </div>
                        <div class="top_part_right">
                            <a href="#" class="btn">
                                <span>Lihat Semua Mobil</span>
                            </a>
                            <div class="controls" id="popular_destination__arrows">
                                <div class="arrow prev"></div>
                                <div class="arrow next"></div>
                            </div>
                        </div>
                    </div>
                    <div class="section_content">
                        <div class="popular_destination__slider" id="popular_destination__slider">
                            <?php include 'koneksi.php';
                            $tampil_data=mysqli_query($konek, "SELECT * FROM tb_unit");
                            while ($data=mysqli_fetch_array($tampil_data, MYSQLI_ASSOC)) {?>
                            <div class="slide_item">
                                <a href="single.php?id=<?php echo $data['id_unit']; ?>" class="slide_item_img">
                                    <div class="sq_parent">
                                        <div class="sq_wrap">
                                            <div class="sq_content" style="background-image: url(berkas/<?php echo $data['gambar']; ?>)"> 
                                            </div>
                                        </div>
                                    </div>
                                </a>
                                <a href="single.php?id=<?php echo $data['id_unit']; ?>" class="slide_item_content">
                                    <h3 class="slide_title">
                                        <?php echo $data['nama']; ?>
                                    </h3>
                                    <p class="slide_text">
                                        <?php echo $data['des']; ?>
                                    </p>
                                </a>
                                <div class="slide_footer">
                                    <div class="hours">Rp. <?php echo number_format($data['harga'],2,'.','.'); ?>/ Hari</div>
                                    <div class="tours_link">
                                        <a href="single.php?id=<?php echo $data['id_unit']; ?>">Lihat Detail Mobil</a>
                                    </div>
                                </div>
                            </div>
                            <?php } ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="discount_section" style="background-image: url(depan/aset/img/home5.jpeg)">
            <div class="wrap">
                <div class="wrap_float">
                    <div class="section_content">
                        <div class="tag">Pilih Mobil</div>
                        <h2 class="section_title">Pot Discount <span class="discount_tag">20% off</span> </h2>
                        <p class="text">
                            Layanan Kami sangat memenuhi kebutuhan mobilitas bisnis Anda secara menyeluruh dengan berbagai solusi transportasi, mulai dari rental mobil jangka pendek dan panjang, dengan sistem pengelolaan armada yang sangat signifikan.
                        </p>
                        <div class="buttons">
                            <a href="index.php" class="btn">Rental Moobil</a>
                            <a href="destinations.php" class="btn btn__choose_tour">Kunjungi</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
       
<?php include 'tem/footer.php'; ?>