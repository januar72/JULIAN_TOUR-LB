<?php 
include 'koneksi.php';
$id =$_GET['id'];

$hapus=mysqli_query($konek, "DELETE FROM tb_katalog WHERE id_katalog='$id'");

header("Location:dashboard_admin.php?p=katalog");
 ?>