<?php 
include 'koneksi.php';

$id =$_GET['id'];

$hapus_data=mysqli_query($konek, "DELETE FROM tb_dest WHERE id_dest='$id'");
header("location:dashboard_admin.php?p=destinasi&notif=sukses_hapus");

 ?>