<?php 
include 'koneksi.php';
$id =$_GET['id'];

$hapus =mysqli_query($konek, "DELETE FROM tb_unit WHERE id_unit='$id'");
header("location:dashboard_admin.php?p=data_mobil&notif=sukses_hapus");
 ?>