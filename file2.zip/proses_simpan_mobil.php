<?php 
include 'koneksi.php';
if (isset($_POST['simpan'])) {
	$direktori ="berkas/";
	$file_name =$_FILES['gambar']['name'];
	move_uploaded_file($_FILES['gambar']['tmp_name'], $direktori . $file_name);

	$nama =$_POST['nama'];
	$harga =$_POST['harga'];
	$des =$_POST['des'];

$simpan_a=mysqli_query($konek, "INSERT INTO `tb_unit` (`id_unit`,`nama`,`harga`,`des`,`gambar`) VALUES (null, '$nama','$harga','$des', '$file_name')");
header("location:dashboard_admin.php?p=data_mobil&notif=sukses");
}

 ?>

