<?php 
include 'koneksi.php';
if (isset($_POST['simpan'])) {
	$nama =$_POST['nama'];
	$email =$_POST['email'];
	$tgl =$_POST['tgl'];
	$jumlah =$_POST['jumlah'];
	$no_wa =$_POST['no_wa'];
	$pesan =$_POST['pesan'];

$simpan =mysqli_query($konek, "INSERT INTO `tb_pesan` (`id_pesan`,`nama`,`email`,`tgl`,`jumlah`,`no_wa`,`pesan`) VALUES (null, '$nama','$email','$tgl','$jumlah','$no_wa','$pesan')");

header("Location:index.php");
}
 ?>