<?php 
include 'koneksi.php';

$id =$_GET['id'];

$hapus=mysqli_query($konek, "DELETE FROM tb_layanan WHERE id_lynan='$id'");
header("Location:dashboard_admin.php?p=data_layanan");
 ?>