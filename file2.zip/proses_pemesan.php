<?php 
include 'koneksi.php';
if (isset($_POST['simpan'])) {
	$direktori ="berkas/";
	$file_name =$_FILES['fot']['name'];
	move_uploaded_file($_FILES['fot']['tmp_name'],$direktori.$file_name);

	$nama =$_POST['nama'];
	$hp =$_POST['hp'];
	$tgl_pesan =$_POST['tgl_pesan'];

$simpan=mysqli_query($konek, "INSERT INTO `tb_pes` (`id_pes`,`nama`,`hp`,`tgl_pesan`,`fot`) VALUES (null, '$nama','$hp','$tgl_pesan','$file_name')");

header("Location:dashboard_admin.php?p=data_pemesan");
}
 ?>