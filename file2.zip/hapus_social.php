<?php 
include 'koneksi.php';
$id =$_GET['id'];

$hapus_a=mysqli_query($konek,"DELETE FROM tb_soc WHERE id_soc='$id'");
header("Location:dashboard_admin.php?p=social_media");
 ?>