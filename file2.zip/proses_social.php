<?php 
include 'koneksi.php';
if (isset($_POST['simpan'])) {
	$hp =$_POST['hp'];
	$email =$_POST['email'];
	$tiktok =$_POST['tiktok'];
	$ig =$_POST['ig'];
	$fb =$_POST['fb'];
	$maps =$_POST['maps'];

$simpan_a=mysqli_query($konek, "INSERT INTO `tb_soc` (`id_soc`,`hp`,`email`,`tiktok`,`ig`,`fb`,`maps`) VALUES (null, '$hp','$email','$tiktok','$ig','$fb','$maps')");
header("Location:dashboard_admin.php?p=social_media");
}
 ?>