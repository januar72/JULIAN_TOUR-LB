<?php include 'tem/header.php'; ?>
        <div class="breadcrumbs">
            <div class="wrap">
                <div class="wrap_float">
                    <a href="index.php">Home</a>
                    <span class="separator">/</span>
                    <a href="#" class="current">Destination</a>
                </div>
            </div>
        </div>
        <div class="image_bg--destinations" style="background-image: url(depan/aset/img/header4.jpeg);"></div>
        <div class="page_content destinations-page">
            <div class="wrap">
                <div class="wrap_float">
                    <?php include 'koneksi.php';
                    $tam_a=mysqli_fetch_array(mysqli_query($konek, "SELECT * FROM tb_katalog")); ?>
                    <div class="section-title"><a href="download.php?filename=<?php echo $tam_a['file_catalog']; ?>"><i class="fa-solid fa-download"></i>  Booklet</a></div>

                    <div class="main">
                        <div class="popular_destination__slider">
                            <?php include 'koneksi.php';
                            $tampil_a=mysqli_query($konek, "SELECT * FROM tb_dest");
                            while ($data=mysqli_fetch_array($tampil_a, MYSQLI_ASSOC)) {?>
                            <div class="slide_item">
                                <a href="#" class="slide_item_img">
                                    <div class="sq_parent">
                                        <div class="sq_wrap">
                                            <div class="sq_content" style="background-image: url(berkas/<?php echo $data['foto']; ?>)"></div>
                                        </div>
                                    </div>
                                </a>
                                <a href="#" class="slide_item_content">
                                    <h3 class="slide_title">
                                        <?php echo $data['nama']; ?>
                                    </h3>
                                    <p class="slide_text">
                                        <?php echo $data['des']; ?>
                                    </p>
                                </a>
                            </div>
                            <?php } ?>
                        </div>
                        <div class="pagination">
                            <ul>
                                <li class="prev"><a href="#"></a></li>
                                <li class="current"><a href="#">1</a></li>
                                <li><a href="#">2</a></li>
                                <li><a href="#">3</a></li>
                                <li><a href="#">4</a></li>
                                <li class="next"><a href="#"></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
<?php include 'tem/footer.php'; ?>