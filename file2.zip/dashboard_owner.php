<?php
 session_start();
 unset($_SESSION['owner']);
 echo "<script>alert('Ops Sedang Maintenace....');
 document.location.href='login.php'</script>\n";
?>
